# Bug World Phase 4

**Software Engineering**

Jacobs University, Spring Semester 2018

Prof. Dr. Peter Baumann

## Contributors for Phase 4


**David Anifowoshe**

**Lorik Mucolli**

## Progress for Phase 4

```
* Created README file
* Implemented instruction_drop.cpp,
* Implemented instruction_flip.cpp,
* Implemented instruction_mark.cpp,
* Implemented instruction_turn.cpp,
* Implemented instruction_unmark.cpp,
* Wrote BugTest.cpp,
* Wrote MarkerTest.cpp
```
