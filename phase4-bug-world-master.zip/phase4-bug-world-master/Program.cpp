#include "Program.h"

Program::Program(std::string filename) {
    /* TODO: to be implemented. */
}

void Program::step(Bug b) {
    /* TODO: to be implemented. */
}